=== Dr. Haiel Chatbot ===
 
Contributors: davidjguan
Tags: 
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
A WordPress plugin that displays a chatbot for hospitals 
 
== Description ==
 
A WordPress plugin that displays a chatbot for hospitals 
 
== Installation ==
 
1. Upload the plugin folder to your /wp-content/plugins/ folder.
1. Go to the **Plugins** page and activate the plugin.
 
== Frequently Asked Questions ==
 
= How do I use this plugin? =
 
Answer to the question
 
= How to uninstall the plugin? =
 
Simply deactivate and delete the plugin. 
 
== Screenshots ==

 
== Changelog ==
= 1.0 =
* Plugin released.